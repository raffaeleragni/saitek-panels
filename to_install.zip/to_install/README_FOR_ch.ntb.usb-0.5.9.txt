this file (ch.ntb.usb-0.5.9.jar) will need to be installed with maven using the folloring command (from the file's directory) in order to compile the program

mvn install:install-file -Dfile=ch.ntb.usb-0.5.9.jar -DgroupId=ch-usb -DartifactId=ch-usb -Dversion=0.5.9 -Dpackaging=jar