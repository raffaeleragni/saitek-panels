the folder libusb-win32-bin-1.2.6.0 can be also downloaded from internet (in case you don't trust given executables...)

1. go to libusb-win32-bin-1.2.6.0/bin
2. exec inf-wizard.exe

panels codes, vendor/product: 
0x06A3/0xD67 : Saitek SWITCH panel
0x06A3/0xD05 : Saitek RADIO panel

For each panel you want to install this driver, go next generating the inf, and then click on "install now...".
Do this for both.